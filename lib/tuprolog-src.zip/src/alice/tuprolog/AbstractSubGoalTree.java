package alice.tuprolog;


public abstract class AbstractSubGoalTree {
    
    public abstract boolean isLeaf();
    
    public abstract boolean isRoot();
    
}